﻿namespace Lektion9Mars14DesignPatterns1.Builder
{
    public class Wheel
    {
    }
}