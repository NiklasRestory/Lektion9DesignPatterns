﻿namespace Lektion9Mars14DesignPatterns1
{
    public class User
    {
    }
}