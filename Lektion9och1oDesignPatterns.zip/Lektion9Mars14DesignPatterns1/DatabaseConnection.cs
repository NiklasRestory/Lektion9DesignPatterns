﻿namespace Lektion9Mars14DesignPatterns1
{
    public class DatabaseConnection
    {
        public List<User> LoadUsers()
        {
            throw new NotImplementedException();
        }
    }
}